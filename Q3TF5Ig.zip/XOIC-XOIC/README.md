# XOIC
Fast DoS &amp; DDoS tool inspired by HOIC

# How to install
 
apt update && apt upgrade

pkg install  python

pkg install git

git clone 
https://github.com/StormRLS/XOIC

cd XOIC
​
# Main Tool:
python XOIC.py

# Hours 2 Seconds
python h2s.py

# Host 2 Up
python host2ip.py
